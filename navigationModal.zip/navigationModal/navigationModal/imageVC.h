//
//  imageVC.h
//  navigationModal
//
//  Created by Manu Sharma on 11/14/12.
//  Copyright (c) 2012 Manu Sharma. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface imageVC : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *img;

@end
